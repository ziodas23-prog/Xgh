# Loop MP3 Player (Android)

Ein einfacher Android-Musikplayer für eigene Audiodateien.

## Enthaltene Funktionen
- Eigene MP3-/Audiodateien über den Android-Dateiauswahldialog hinzufügen
- Wiedergabe, Pause, nächster/vorheriger Titel
- Wiederholungsmodi: Aus, einzelner Titel, gesamte Playlist
- Zufallswiedergabe
- Fortschrittsanzeige und Playlist-Übersicht
- Hintergrundwiedergabe über Media3 MediaSessionService

## APK nur mit dem Handy bauen (über GitHub Actions)
Dieses ZIP enthält einen Workflow unter `.github/workflows/build-apk.yml`, der die APK in GitHub baut.

1. Auf dem Handy im Browser bei https://github.com anmelden oder kostenlos ein Konto erstellen.
2. Ein neues Repository erstellen. Den Namen kannst du z. B. `LoopMP3Player` nennen. Für die einfachste Einrichtung kann es **Public** sein.
3. Im neuen Repository **Add file > Upload files** wählen.
4. Die ZIP-Datei zuerst auf dem Handy entpacken. Alle enthaltenen Dateien und Ordner hochladen, auch den versteckten Ordner `.github` mit dem Workflow. Falls der Datei-Manager versteckte Ordner nicht anzeigt, aktiviere dort „Versteckte Dateien anzeigen“.
5. Unten **Commit changes** drücken und auf den Tab **Actions** gehen.
6. Den Workflow **Build Android APK** öffnen. Falls er nicht automatisch läuft: **Run workflow** wählen.
7. Warten, bis der Lauf grün abgeschlossen ist. Den Lauf öffnen und unter **Artifacts** `LoopMP3Player-debug-apk` herunterladen.
8. Das heruntergeladene Artefakt-ZIP entpacken. Darin liegt `app-debug.apk`. Antippen und installieren. Android kann vorher nach Erlaubnis zum Installieren aus dieser Quelle fragen.

## Hinweise
- Das Projekt ist Quellcode und keine APK. Der GitHub-Workflow erstellt eine Debug-APK in der Cloud.
- Die ausgewählten Audiodateien werden über Androids Dateiauswahl geöffnet; kein pauschaler Zugriff auf den gesamten Speicher ist nötig.
- Android Studio bzw. der Cloud-Build benötigt Internet, um Gradle und Bibliotheken herunterzuladen.
