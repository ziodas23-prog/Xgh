package de.example.loopmp3

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var playlistText: TextView
    private lateinit var playButton: Button
    private lateinit var repeatButton: Button
    private lateinit var shuffleButton: Button
    private lateinit var seekBar: SeekBar
    private lateinit var currentTime: TextView
    private lateinit var totalTime: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private val pickedUris = mutableListOf<Uri>()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        pickedUris.clear()
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: Exception) { }
            pickedUris.add(uri)
        }
        val serviceIntent = Intent(this, PlaybackService::class.java).apply {
            action = PlaybackService.ACTION_SET_PLAYLIST
            putStringArrayListExtra(PlaybackService.EXTRA_URIS, ArrayList(pickedUris.map { it.toString() }))
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        updatePlaylistNames()
        handler.postDelayed({ refreshUi() }, 700)
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            refreshProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = findViewById(R.id.songTitle)
        subtitle = findViewById(R.id.songSubtitle)
        playlistText = findViewById(R.id.playlistText)
        playButton = findViewById(R.id.playButton)
        repeatButton = findViewById(R.id.repeatButton)
        shuffleButton = findViewById(R.id.shuffleButton)
        seekBar = findViewById(R.id.seekBar)
        currentTime = findViewById(R.id.currentTime)
        totalTime = findViewById(R.id.totalTime)

        findViewById<Button>(R.id.addButton).setOnClickListener { picker.launch(arrayOf("audio/mpeg", "audio/*")) }
        playButton.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
            refreshUi()
        }
        findViewById<Button>(R.id.nextButton).setOnClickListener { controller?.seekToNextMediaItem() }
        findViewById<Button>(R.id.previousButton).setOnClickListener { controller?.seekToPreviousMediaItem() }
        repeatButton.setOnClickListener {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
                    Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
                    else -> Player.REPEAT_MODE_OFF
                }
                updateModeButtons()
            }
        }
        shuffleButton.setOnClickListener {
            controller?.let {
                it.shuffleModeEnabled = !it.shuffleModeEnabled
                updateModeButtons()
            }
        }
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(bar: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(bar: SeekBar?) {
                bar?.let { controller?.seekTo(it.progress.toLong()) }
                userSeeking = false
            }
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {}
        })
        connectController()
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refreshUi()
                    override fun onIsPlayingChanged(isPlaying: Boolean) = refreshUi()
                    override fun onPlaybackStateChanged(playbackState: Int) = refreshUi()
                })
                refreshUi()
            } catch (_: Exception) {
                subtitle.text = "Player konnte nicht gestartet werden."
            }
        }, Executor { it.run() })
    }

    private fun updatePlaylistNames() {
        playlistText.text = pickedUris.mapIndexed { index, uri ->
            "${index + 1}. ${uri.lastPathSegment?.substringAfterLast('/') ?: "MP3-Datei"}"
        }.joinToString("\n")
    }

    private fun refreshUi() {
        val p = controller ?: return
        title.text = p.currentMediaItem?.mediaMetadata?.title ?: "Noch kein Song ausgewählt"
        subtitle.text = if (p.mediaItemCount > 0) "Track ${p.currentMediaItemIndex + 1} von ${p.mediaItemCount}" else "Füge deine MP3-Dateien hinzu"
        playButton.text = if (p.isPlaying) "Ⅱ" else "▶"
        updateModeButtons()
        refreshProgress()
    }

    private fun updateModeButtons() {
        val p = controller ?: return
        repeatButton.text = "Wiederholen: " + when (p.repeatMode) {
            Player.REPEAT_MODE_ONE -> "Einzeln"
            Player.REPEAT_MODE_ALL -> "Alle"
            else -> "Aus"
        }
        shuffleButton.text = if (p.shuffleModeEnabled) "Zufall: An" else "Zufall: Aus"
    }

    private fun refreshProgress() {
        val p = controller ?: return
        val duration = p.duration.takeIf { it > 0 } ?: 0L
        val position = p.currentPosition.coerceAtLeast(0L)
        if (!userSeeking) {
            seekBar.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            seekBar.progress = position.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }
        currentTime.text = formatTime(position)
        totalTime.text = formatTime(duration)
    }

    private fun formatTime(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(seconds / 60, seconds % 60)
    }

    override fun onStart() {
        super.onStart()
        handler.post(progressRunnable)
    }

    override fun onStop() {
        handler.removeCallbacks(progressRunnable)
        super.onStop()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
