package de.example.loopmp3

import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build()
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SET_PLAYLIST) {
            val uris = intent.getStringArrayListExtra(EXTRA_URIS).orEmpty()
            val items = uris.map { uriString ->
                val uri = android.net.Uri.parse(uriString)
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "MP3"
                MediaItem.Builder()
                    .setUri(uri)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(name).build())
                    .build()
            }
            if (items.isNotEmpty()) {
                player.setMediaItems(items)
                player.prepare()
                player.play()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_SET_PLAYLIST = "de.example.loopmp3.SET_PLAYLIST"
        const val EXTRA_URIS = "uris"
    }
}
